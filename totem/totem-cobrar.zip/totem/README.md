# Totem Climb Gym — Sistema de membresías y facturación

Aplicación web local en Flask + PostgreSQL, organizada por capas.

## Puesta en marcha

### 1. Dependencias

```bash
python -m venv .venv
source .venv/bin/activate        # en Windows:  .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Base de datos

```bash
createdb totem
psql -d totem -f totem-schema-final.sql
```

### 3. Configuración

```bash
cp .env.example .env
```

Edita `.env` con los datos de tu PostgreSQL y genera una clave real:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

### 4. Contraseña del administrador

El script SQL crea el usuario `admin` con un marcador que **no** permite
entrar. Hay que establecer la contraseña real:

```bash
python -m scripts.crear_admin
```

Para crear vendedores:

```bash
python -m scripts.crear_admin --usuario camila --rol VENDEDOR \
       --nombre Camila --apellido Rojas
```

### 5. El logo

Copia `totem-logo.png` (el mismo de las maquetas) en:

```
app/static/img/totem-logo.png
```

### 6. Levantar la aplicación

```bash
python run.py          # desarrollo, en http://localhost:5000
```

En producción no se usa ese servidor:

```bash
gunicorn -w 3 -b 127.0.0.1:8000 "run:app"
```

## Estructura

```
totem/
├── run.py                  Punto de entrada
├── config.py               Configuración desde variables de entorno
├── app/
│   ├── __init__.py         Fábrica de la aplicación
│   ├── db.py               Pool de conexiones a PostgreSQL
│   ├── security.py         Sesión y control de acceso por rol
│   ├── models/             Objetos de dominio, sin lógica
│   ├── repositories/       Todo el SQL vive aquí
│   ├── services/           Reglas de negocio
│   ├── routes/             Blueprints de Flask (la interfaz)
│   ├── templates/          Plantillas Jinja2
│   └── static/             CSS, imágenes
└── scripts/                Utilidades de línea de comandos
```

La separación es la que define el proyecto: una vista nunca escribe SQL,
un repositorio nunca decide reglas de negocio, y un servicio no sabe que
existe HTTP. Para agregar un módulo se sigue siempre el mismo camino:
modelo, repositorio, servicio, ruta y plantilla.

## Roles

| | VENDEDOR | ADMIN |
|---|---|---|
| Trabajo diario (clientes, cobros, calendario) | Sí | Sí |
| Bitácora de movimientos | No | Sí |
| Cambiar el IVA | No | Sí |

El decorador `@login_requerido` protege las vistas normales y
`@admin_requerido` las del administrador.

## Seguridad

- Contraseñas con hash **bcrypt**; el texto plano no se guarda nunca.
- Mismo mensaje de error para usuario inexistente y contraseña errada,
  y verificación de igual duración en ambos casos, para no revelar qué
  usuarios existen.
- Bloqueo tras 5 intentos fallidos durante 5 minutos (configurable).
- Cookies de sesión `HttpOnly` y `SameSite=Lax`. Al pasar a HTTPS, hay
  que poner `SESSION_COOKIE_SECURE=True` en el `.env`.
- El hash nunca sale de la capa de servicios hacia las vistas.

El control de intentos fallidos vive en memoria del proceso. Si algún día
se levantan varios procesos de gunicorn, hay que moverlo a la base de
datos o a Redis.

## Módulo de clientes

Pantallas: listado con buscador y filtros, alta, edición y perfil del
menor a cargo.

Reglas implementadas:

- La cédula es opcional, pero si se registra se valida con el dígito
  verificador ecuatoriano y no puede repetirse.
- A un titular se le exige al menos un celular o un correo. A un menor no,
  porque se contacta a través de su representante.
- Los menores a cargo se crean como clientes ligados al representante, en
  la misma transacción: si falla uno, no queda el representante a medias.
- El estado de la membresía (vigente, por vencer, vencido) se calcula al
  vuelo desde la fecha de fin. "Por vencer" son los próximos 7 días.
- La edad y el aviso de mayoría de edad se calculan desde la fecha de
  nacimiento, sin guardar nada extra.
- Cada alta y cada edición quedan en la bitácora, con los valores de antes
  y después de cada campo que cambió.

Pendiente en este módulo: agendar la clase de prueba desde el alta del
cliente. Depende del módulo de Calendario, que todavía no existe.

## Módulo de catálogo (productos y planes)

Una sola pantalla con dos pestañas: **Catálogo** para los artículos que se
venden (nombre y precio) y **Planes de membresía** para los planes con
vigencia. El alta es un formulario único con un toggle Producto / Membresía.

Reglas implementadas:

- Los precios no pueden ser negativos y aceptan coma o punto decimal.
- Un plan tipo Pases debe indicar cuántas entradas incluye; los planes
  mensuales no guardan ese dato aunque se envíe.
- Los nombres no se repiten, sin importar mayúsculas.
- Nada se borra: lo que deja de venderse se desactiva. Desaparece de la
  lista al cobrar, pero las facturas anteriores siguen intactas. Por eso
  este módulo agrega la columna `productos.activo`.

## Módulo de cobro

Pantalla de Cobrar con buscador de cliente, lista única de productos y
planes, totales en vivo y comprobante al final.

Reglas implementadas:

- **Los totales se recalculan siempre en el servidor** con los precios de
  la base. Lo que manda el navegador solo dice qué ítems y en qué
  cantidad; un precio enviado desde el cliente se ignora.
- Si cualquier ítem tiene `permite_descuento = false`, el descuento se
  bloquea para la factura completa.
- Un plan con `permite_pareja` pide una segunda persona y genera dos
  membresías enlazadas entre sí, desde una sola factura y un solo cobro.
- **Renovación anticipada:** si el cliente todavía tiene vigencia, la
  nueva membresía empieza el día en que termina la anterior, para que no
  pierda los días que ya pagó.
- Los pases copian sus entradas del plan a `dias_totales` y
  `dias_restantes`.
- Fiar deja la factura en `PENDIENTE` con su saldo; el monto recibido al
  momento se guarda como el primer abono en `pagos_fiado`.
- El IVA se lee de `configuracion` y se guarda en cada factura, así un
  cambio futuro no altera las facturas anteriores.
- Todo el cobro ocurre en una sola transacción: factura, detalle,
  membresías y abono, o nada.

La numeración usa la secuencia `seq_numero_factura`, para que dos cobros
simultáneos nunca reciban el mismo número.

## Lo que sigue

Módulos pendientes, en orden sugerido: facturas, contabilidad y
calendario. Las maquetas HTML de cada uno ya
están hechas y sirven de referencia visual.
